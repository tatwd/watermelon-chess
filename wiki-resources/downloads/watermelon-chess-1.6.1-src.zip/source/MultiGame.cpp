#include "MultiGame.h"

MultiGame::MultiGame()
{

}

MultiGame::~MultiGame()
{

}


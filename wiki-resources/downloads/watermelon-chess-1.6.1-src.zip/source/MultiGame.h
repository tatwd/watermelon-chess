#ifndef MULTIGAME_H
#define MULTIGAME_H

#include "Board.h"

class MultiGame : public Board
{
public:
    MultiGame();
    ~MultiGame();
};

#endif // MULTIGAME_H
